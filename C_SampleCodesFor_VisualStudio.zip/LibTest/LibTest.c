#include <stdio.h>

void PrintData(int nParam)
{
	printf("PrintData() : %d\n", nParam);
}

void PrintString(const char *pszParam)
{
	printf("PrintString() : %s\n", pszParam);
}

