#pragma once

void PrintData(int);
void PrintString(const char *);

