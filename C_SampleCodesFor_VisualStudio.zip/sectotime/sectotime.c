#include<stdio.h>

int main(void)
{
	int nSec = 0;
	scanf("%d", &nSec);
	printf("%d�ʴ� %02d�ð� %02d�� %02d�� �Դϴ�.\n",
		nSec,
		nSec / 3600,
		nSec % 3600 / 60,
		nSec % 60);
	return 0;
}


