#include "LibTest.h"

#pragma comment(lib, "LibTest")

int main(void)
{
	PrintData(10);
	PrintString("Test string");
	return 0;
}

