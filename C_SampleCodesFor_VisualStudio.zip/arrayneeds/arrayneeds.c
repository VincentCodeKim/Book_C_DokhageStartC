#include <stdio.h>

int main(void)
{
	int a, b, c, d, e;

	scanf("%d%d%d%d%d", &a, &b, &c, &d, &e);

	printf("%d\n", a);
	printf("%d\n", b);
	printf("%d\n", c);
	printf("%d\n", d);
	printf("%d\n", e);
	return 0;
}
